import React, { Component } from "react";
import Grid from "./Grid";

class Page2 extends Component {
  state = {};
  render() {
    return <Grid></Grid>;
  }
}

export default Page2;
